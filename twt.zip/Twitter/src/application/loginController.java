package application;

import java.io.IOException;
import java.sql.SQLException;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class loginController {

	@FXML
	private AnchorPane logIn;
	@FXML
	private TextField id;
	@FXML
	private TextField pw;
	@FXML
	
	

	static DBConnection db_conn;

	public void showRegForm() throws IOException, SQLException {

		Stage newStage = new Stage();
		Stage stage = (Stage) logIn.getScene().getWindow();

		try {

			// 새 레이아웃 추가
			Parent second = FXMLLoader.load(getClass().getResource("reg.fxml"));

			// 씬에 레이아웃 추가
			Scene sc = new Scene(second);

			// 씬을 스테이지에서 상영
			newStage.setScene(sc);
			newStage.show();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public void login() throws IOException, SQLException {

		if (!db_conn.Login(id.getText(), pw.getText())) { // abcd 계정 로그인 성공하면 true/ 실패하면 false 리턴
			System.out.println("로그인 에러");
			// return; //경고창 띄우기
		}
		controller.ID = id.getText();//ID정보를 controller에게 넘김
		
		Stage newStage = new Stage();
		Stage stage = (Stage) logIn.getScene().getWindow();

		try {

			// 새 레이아웃 추가
			Parent second = FXMLLoader.load(getClass().getResource("window.fxml"));

			// 씬에 레이아웃 추가
			Scene sc = new Scene(second);

			// 씬을 스테이지에서 상영
			newStage.initStyle(StageStyle.UNDECORATED);
			newStage.setResizable(false);
			newStage.setScene(sc);
			newStage.show();
			
			
			// 기존 페이지 삭제
			stage.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void closeStage() {
		Stage stage11 = (Stage) logIn.getScene().getWindow();
		Platform.runLater(() -> {
			stage11.close();
		});
	}

	@FXML
	public void minclick(MouseEvent event) throws IOException {

		((Stage) ((Circle) event.getSource()).getScene().getWindow()).setIconified(true);

	}

	/**** close screen ****/
	@FXML
	public void closeclick(MouseEvent event) throws IOException {

		System.exit(0);

	}
}
