package application;

public class Adapter {
	
	public static void write(String title, String content) {
		
	}
}
