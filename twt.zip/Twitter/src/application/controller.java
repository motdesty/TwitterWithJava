package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class controller {

	@FXML
	private Button btn1;

	@FXML
	private Button btn2;

	@FXML
	private Button btn3;

	@FXML
	private Button btn4;

	@FXML
	private Pane panel;
	@FXML
	private Label label1;
	@FXML
	private Label label2;
	@FXML
	private GridPane pn1;

	@FXML
	private GridPane pn2;
	@FXML
	private GridPane pn3;
	@FXML
	private GridPane pn4;
	
	@FXML
	private TextArea ta2;//for write a post
	@FXML
	private VBox post;//for visualize posts
	@FXML
	private GridPane postGrid;
	

//	@FXML
//	private TextField tf2;

	static DBConnection db_conn;
	static String ID;
//	private List<post> posts;
	
//	private  List<post> data(){
//		List<post> ls = new ArrayList();
//		post post = new post();
//		post.setId(ID);
//		post.setDate(ID);
//		post.setContent(ID);
//		ls.add(post);
//		return ls;
//	}
	
	public void writePost() throws SQLException { // 자신의 피드에 글 쓰기

		String content = ta2.getText();// text area에서 내용 불러오기
		db_conn.WritePost(ID, content);// 쿼리실행
		ta2.setText("");// txt area 초기화
	}

	public void readPost() throws SQLException, IOException {
		ArrayList<HashMap<String, Object>> post_list = db_conn.GetAllPost("1");// username이 1인 유저의 모든 포스트(트윗, 리트윗)을 arraylist로 반환
		Parent second = FXMLLoader.load(getClass().getResource("zz.fxml"));
		Parent third = FXMLLoader.load(getClass().getResource("zz.fxml"));
		
		for (int i = 0; i < post_list.size(); i++) {
			for (Map.Entry<String, Object> elem : post_list.get(i).entrySet()) {


				
				System.out.println(String.format("%s: %s", elem.getKey(), elem.getValue()));
			}
		}

	}

	public void handleClick(ActionEvent e) throws SQLException {
		if (e.getSource() == btn1) {
			label1.setText("event1");
			label2.setText("btn1");
			panel.setBackground(
			new Background(new BackgroundFill(Color.rgb(222, 245, 229), CornerRadii.EMPTY, Insets.EMPTY)));
			pn1.toBack();

		} else if (e.getSource() == btn2) {
			label1.setText("event2");
			label2.setText("btn2");
			panel.setBackground(
					new Background(new BackgroundFill(Color.rgb(188, 234, 213), CornerRadii.EMPTY, Insets.EMPTY)));
			pn2.toBack();
		} else if (e.getSource() == btn3) {
			label1.setText("event3");
			label2.setText("btn3");
			panel.setBackground(
					new Background(new BackgroundFill(Color.rgb(158, 213, 197), CornerRadii.EMPTY, Insets.EMPTY)));
			pn3.toBack();
		} else if (e.getSource() == btn4) {
			label1.setText("event4");
			label2.setText("btn4");
			panel.setBackground(
					new Background(new BackgroundFill(Color.rgb(142, 195, 176), CornerRadii.EMPTY, Insets.EMPTY)));
			pn4.toBack();
		}
	}

	static void PrintList(ArrayList<HashMap<String, Object>> list) { // ArrayList <HashMap<String,Object>> 형식을 프린트
		for (int i = 0; i < list.size(); i++) {
			System.out.println("list 순서 " + i + "번쨰");
			for (Map.Entry<String, Object> elem : list.get(i).entrySet()) {
				System.out.println(String.format("%s: %s", elem.getKey(), elem.getValue()));
			}
		}
	}
	
	@FXML
	public void minclick(MouseEvent event) throws IOException {

		((Stage) ((Circle) event.getSource()).getScene().getWindow()).setIconified(true);

	}

	/**** close screen ****/
	@FXML
	public void closeclick(MouseEvent event) throws IOException {

		System.exit(0);

	}
	public void close(MouseEvent e) {
		System.exit(0); 	
	}

//	@Override
//	public void initialize(URL arg0, ResourceBundle arg1) {
//		// TODO Auto-generated method stub
//		int c = 0;
//		int r = 1;
//		for(int i = 0; i < posts.size(); i++) {
//			FXMLLoader fx = new FXMLLoader();
//			fx.setLocation(getClass().getResource("post.fxml"));
//			
//			VBox pb = fx.load();
//			
//			postController pc = fx.getController();
//			pc.setData(posts.get(i));
//		}
//		postGrid.add(pb, 1, r);
//
//		
//	}
}
