package application;

import java.io.IOException;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class regiController {
	
	@FXML
	private TextField rid;// from regiform
	@FXML
	private TextField pw1;// from regiform
	@FXML
	private TextField pw2;// from regiform
	@FXML
	private AnchorPane reg;// from regiform

	static DBConnection db_conn;

	public void regi() throws IOException, SQLException {
		int result = db_conn.CreateUser(rid.getText(), pw1.getText());
		if(result == 1) {
			System.out.println("Success");//추후에 알러트 박스로 바꾸기
		}else if(result == 2) {
			System.out.println("Duplicated ID");
		}else {
			System.out.println("Registering ERROR");
		}
	}

	@FXML
	public void minclick(MouseEvent event) throws IOException {

		((Stage) ((Circle) event.getSource()).getScene().getWindow()).setIconified(true);

	}

	/**** close screen ****/
	@FXML
	public void closeclick(MouseEvent event) throws IOException {

		System.exit(0);

	}
}
